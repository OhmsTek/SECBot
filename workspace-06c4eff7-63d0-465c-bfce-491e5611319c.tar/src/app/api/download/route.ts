import { db } from '@/lib/db';
import { NextRequest, NextResponse } from 'next/server';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { email, companyTicker, reportType = 'quarterly_report' } = body;

    if (!email) {
      return NextResponse.json({ error: 'Email is required' }, { status: 400 });
    }

    const signup = await db.emailSignup.findUnique({ where: { email } });
    if (!signup) {
      return NextResponse.json(
        { error: 'Please sign up first to download reports' },
        { status: 403 }
      );
    }

    let companyId: string | null = null;
    if (companyTicker) {
      const company = await db.sP500Company.findUnique({
        where: { ticker: companyTicker.toUpperCase() },
      });
      if (company) companyId = company.id;
    }

    const download = await db.download.create({
      data: {
        signupId: signup.id,
        companyId,
        reportType,
      },
    });

    const token = `${signup.id}_${companyId || 'all'}_${download.id}`;
    const downloadUrl = `/api/download-file?token=${encodeURIComponent(token)}`;

    return NextResponse.json({
      success: true,
      downloadUrl,
      message: 'Report ready for download',
    });
  } catch (error) {
    console.error('Error creating download:', error);
    return NextResponse.json(
      { error: 'Failed to create download' },
      { status: 500 }
    );
  }
}