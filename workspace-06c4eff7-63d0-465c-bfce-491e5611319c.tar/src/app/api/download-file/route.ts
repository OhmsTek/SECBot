import { db } from '@/lib/db';
import { NextRequest, NextResponse } from 'next/server';

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const token = searchParams.get('token');

    if (!token) {
      return NextResponse.json({ error: 'Token is required' }, { status: 400 });
    }

    const parts = token.split('_');
    if (parts.length < 3) {
      return NextResponse.json({ error: 'Invalid token' }, { status: 400 });
    }

    const signupId = parts[0];
    const companyId = parts[1];
    const downloadId = parts[2];

    const [signup, download] = await Promise.all([
      db.emailSignup.findUnique({ where: { id: signupId } }),
      db.download.findUnique({ where: { id: downloadId } }),
    ]);

    if (!signup || !download) {
      return NextResponse.json({ error: 'Invalid access' }, { status: 403 });
    }

    let company = null;
    let reports: Array<{
      quarter: string;
      period: string;
      revenue: string | null;
      netIncome: string | null;
      eps: string | null;
      grossMargin: string | null;
      operatingMargin: string | null;
      netMargin: string | null;
      revenueGrowth: string | null;
      earningsGrowth: string | null;
      freeCashFlow: string | null;
      totalDebt: string | null;
      totalAssets: string | null;
      shareholdersEquity: string | null;
      returnOnEquity: string | null;
      analysis: string | null;
      highlights: string | null;
    }> = [];

    if (companyId && companyId !== 'all') {
      company = await db.sP500Company.findUnique({
        where: { id: companyId },
        include: {
          reports: { orderBy: { period: 'desc' } },
        },
      });
      if (company) {
        reports = company.reports;
      }
    }

    // Generate HTML report
    const html = generateReportHTML(company, reports, signup);

    return new NextResponse(html, {
      headers: {
        'Content-Type': 'text/html; charset=utf-8',
        'Content-Disposition': company
          ? `inline; filename="${company.ticker}_quarterly_report.html"`
          : 'inline; filename="sp500_report.html"',
      },
    });
  } catch (error) {
    console.error('Error generating report:', error);
    return NextResponse.json({ error: 'Failed to generate report' }, { status: 500 });
  }
}

function generateReportHTML(
  company: {
    ticker: string;
    name: string;
    sector: string;
    subSector: string;
    marketCap: string;
    description: string | null;
    headquarters: string | null;
    employees: number | null;
    website: string | null;
  } | null,
  reports: Array<{
    quarter: string;
    period: string;
    revenue: string | null;
    netIncome: string | null;
    eps: string | null;
    grossMargin: string | null;
    operatingMargin: string | null;
    netMargin: string | null;
    revenueGrowth: string | null;
    earningsGrowth: string | null;
    freeCashFlow: string | null;
    totalDebt: string | null;
    totalAssets: string | null;
    shareholdersEquity: string | null;
    returnOnEquity: string | null;
    analysis: string | null;
    highlights: string | null;
  }>,
  signup: { email: string; firstName: string | null; lastName: string | null }
) {
  const date = new Date().toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });

  const reportRows = reports
    .map(
      (r) => `
    <tr>
      <td style="padding:10px;border:1px solid #e5e7eb;font-weight:600;">${r.quarter}</td>
      <td style="padding:10px;border:1px solid #e5e7eb;">${r.revenue || 'N/A'}</td>
      <td style="padding:10px;border:1px solid #e5e7eb;">${r.netIncome || 'N/A'}</td>
      <td style="padding:10px;border:1px solid #e5e7eb;">${r.eps || 'N/A'}</td>
      <td style="padding:10px;border:1px solid #e5e7eb;">${r.grossMargin || 'N/A'}</td>
      <td style="padding:10px;border:1px solid #e5e7eb;">${r.operatingMargin || 'N/A'}</td>
      <td style="padding:10px;border:1px solid #e5e7eb;">${r.revenueGrowth || 'N/A'}</td>
      <td style="padding:10px;border:1px solid #e5e7eb;">${r.earningsGrowth || 'N/A'}</td>
    </tr>`
    )
    .join('');

  const latestReport = reports[0];
  const balanceSheetRows = latestReport
    ? `
    <tr><td style="padding:8px 10px;border:1px solid #e5e7eb;">Free Cash Flow</td><td style="padding:8px 10px;border:1px solid #e5e7eb;text-align:right;font-weight:600;">${latestReport.freeCashFlow || 'N/A'}</td></tr>
    <tr><td style="padding:8px 10px;border:1px solid #e5e7eb;">Total Debt</td><td style="padding:8px 10px;border:1px solid #e5e7eb;text-align:right;font-weight:600;">${latestReport.totalDebt || 'N/A'}</td></tr>
    <tr><td style="padding:8px 10px;border:1px solid #e5e7eb;">Total Assets</td><td style="padding:8px 10px;border:1px solid #e5e7eb;text-align:right;font-weight:600;">${latestReport.totalAssets || 'N/A'}</td></tr>
    <tr><td style="padding:8px 10px;border:1px solid #e5e7eb;">Shareholders' Equity</td><td style="padding:8px 10px;border:1px solid #e5e7eb;text-align:right;font-weight:600;">${latestReport.shareholdersEquity || 'N/A'}</td></tr>
    <tr><td style="padding:8px 10px;border:1px solid #e5e7eb;">Return on Equity</td><td style="padding:8px 10px;border:1px solid #e5e7eb;text-align:right;font-weight:600;">${latestReport.returnOnEquity || 'N/A'}</td></tr>
    <tr><td style="padding:8px 10px;border:1px solid #e5e7eb;">Net Margin</td><td style="padding:8px 10px;border:1px solid #e5e7eb;text-align:right;font-weight:600;">${latestReport.netMargin || 'N/A'}</td></tr>`
    : '';

  const analysisHtml = latestReport?.analysis
    ? `
    <div style="margin-top:32px;">
      <h2 style="font-size:20px;color:#111827;margin-bottom:16px;padding-bottom:8px;border-bottom:2px solid #059669;">AI-Powered Analysis — ${latestReport.quarter}</h2>
      <div style="line-height:1.8;color:#374151;font-size:14px;white-space:pre-wrap;">${latestReport.analysis}</div>
    </div>`
    : `
    <div style="margin-top:32px;padding:16px;background:#f0fdf4;border:1px solid #bbf7d0;border-radius:8px;">
      <p style="color:#166534;margin:0;"><strong>Note:</strong> AI-powered analysis is available on the platform. Visit the company page to generate a detailed AI analysis based on the latest SEC filings.</p>
    </div>`;

  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${company ? `${company.name} (${company.ticker})` : 'S&P 500'} — Quarterly Analysis Report</title>
  <style>
    @media print {
      .no-print { display: none !important; }
      body { margin: 0; }
    }
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body { font-family: 'Segoe UI', system-ui, -apple-system, sans-serif; color: #1f2937; line-height: 1.6; }
  </style>
</head>
<body>
  <div style="max-width:900px;margin:0 auto;padding:40px 20px;">
    <!-- Header -->
    <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:40px;padding-bottom:20px;border-bottom:3px solid #059669;">
      <div>
        <div style="font-size:12px;color:#059669;font-weight:700;letter-spacing:2px;text-transform:uppercase;margin-bottom:4px;">SEC Filing Analysis</div>
        <h1 style="font-size:28px;color:#111827;font-weight:800;">${company ? `${company.name} (${company.ticker})` : 'S&P 500 Quarterly Report'}</h1>
        ${company ? `<p style="color:#6b7280;font-size:14px;margin-top:4px;">${company.sector} · ${company.subSector}</p>` : ''}
      </div>
      <div style="text-align:right;">
        <div style="font-size:12px;color:#6b7280;">Report Date</div>
        <div style="font-weight:600;color:#374151;">${date}</div>
        <div style="font-size:11px;color:#9ca3af;margin-top:4px;">Prepared for: ${signup.email}</div>
      </div>
    </div>

    ${company ? `
    <!-- Company Overview -->
    <div style="background:#f9fafb;border-radius:8px;padding:20px;margin-bottom:32px;">
      <h2 style="font-size:16px;color:#111827;margin-bottom:12px;">Company Overview</h2>
      <p style="color:#4b5563;font-size:14px;margin-bottom:12px;">${company.description || ''}</p>
      <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:12px;">
        <div><span style="font-size:12px;color:#6b7280;">Market Cap</span><br><strong>${company.marketCap}</strong></div>
        <div><span style="font-size:12px;color:#6b7280;">Headquarters</span><br><strong>${company.headquarters || 'N/A'}</strong></div>
        <div><span style="font-size:12px;color:#6b7280;">Employees</span><br><strong>${company.employees?.toLocaleString() || 'N/A'}</strong></div>
        <div><span style="font-size:12px;color:#6b7280;">Website</span><br><strong>${company.website || 'N/A'}</strong></div>
      </div>
    </div>
    ` : ''}

    <!-- Financial Summary Table -->
    ${reports.length > 0 ? `
    <div style="margin-bottom:32px;">
      <h2 style="font-size:20px;color:#111827;margin-bottom:16px;padding-bottom:8px;border-bottom:2px solid #059669;">Quarterly Financial Summary</h2>
      <div style="overflow-x:auto;">
        <table style="width:100%;border-collapse:collapse;font-size:13px;">
          <thead>
            <tr style="background:#f9fafb;">
              <th style="padding:10px;border:1px solid #e5e7eb;text-align:left;font-weight:700;">Quarter</th>
              <th style="padding:10px;border:1px solid #e5e7eb;text-align:left;font-weight:700;">Revenue</th>
              <th style="padding:10px;border:1px solid #e5e7eb;text-align:left;font-weight:700;">Net Income</th>
              <th style="padding:10px;border:1px solid #e5e7eb;text-align:left;font-weight:700;">EPS</th>
              <th style="padding:10px;border:1px solid #e5e7eb;text-align:left;font-weight:700;">Gross Margin</th>
              <th style="padding:10px;border:1px solid #e5e7eb;text-align:left;font-weight:700;">Op. Margin</th>
              <th style="padding:10px;border:1px solid #e5e7eb;text-align:left;font-weight:700;">Rev Growth</th>
              <th style="padding:10px;border:1px solid #e5e7eb;text-align:left;font-weight:700;">EPS Growth</th>
            </tr>
          </thead>
          <tbody>${reportRows}</tbody>
        </table>
      </div>
    </div>

    <!-- Balance Sheet -->
    ${balanceSheetRows ? `
    <div style="margin-bottom:32px;">
      <h2 style="font-size:20px;color:#111827;margin-bottom:16px;padding-bottom:8px;border-bottom:2px solid #059669;">Balance Sheet — ${latestReport.quarter}</h2>
      <table style="width:100%;max-width:400px;border-collapse:collapse;font-size:14px;">
        <tbody>${balanceSheetRows}</tbody>
      </table>
    </div>
    ` : ''}
    ` : '<p style="color:#6b7280;">No quarterly reports available yet.</p>'}

    <!-- AI Analysis -->
    ${analysisHtml}

    <!-- Footer -->
    <div style="margin-top:48px;padding-top:20px;border-top:1px solid #e5e7eb;text-align:center;">
      <p style="font-size:11px;color:#9ca3af;">This report was generated by S&P 500 SEC Filing Analysis Platform. Data sourced from SEC EDGAR filings and AI-powered analysis.</p>
      <p style="font-size:11px;color:#9ca3af;margin-top:4px;">This report is for informational purposes only and does not constitute investment advice.</p>
      <div class="no-print" style="margin-top:16px;">
        <button onclick="window.print()" style="background:#059669;color:white;border:none;padding:10px 24px;border-radius:6px;font-size:14px;font-weight:600;cursor:pointer;">Save as PDF</button>
      </div>
    </div>
  </div>
</body>
</html>`;
}