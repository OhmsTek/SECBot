import { db } from '@/lib/db';
import { NextResponse } from 'next/server';

export async function GET() {
  try {
    const [totalCompanies, totalReports, totalSignups, sectorCount] =
      await Promise.all([
        db.sP500Company.count(),
        db.quarterlyReport.count(),
        db.emailSignup.count(),
        db.sP500Company.groupBy({ by: ['sector'] }).then((r) => r.length),
      ]);

    return NextResponse.json({
      totalCompanies,
      totalReports,
      totalSignups,
      sectors: sectorCount,
    });
  } catch (error) {
    console.error('Error fetching stats:', error);
    return NextResponse.json({ error: 'Failed to fetch stats' }, { status: 500 });
  }
}