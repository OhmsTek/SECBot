import { db } from '@/lib/db';
import { NextRequest, NextResponse } from 'next/server';

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const search = searchParams.get('search') || '';
    const sector = searchParams.get('sector') || '';
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '20');
    const skip = (page - 1) * limit;

    const where: Record<string, unknown> = {};

    if (search) {
      where.OR = [
        { ticker: { contains: search.toUpperCase() } },
        { name: { contains: search, mode: 'insensitive' } },
        { sector: { contains: search, mode: 'insensitive' } },
      ];
    }

    if (sector) {
      where.sector = sector;
    }

    const [companies, total] = await Promise.all([
      db.sP500Company.findMany({
        where,
        skip,
        take: limit,
        orderBy: { marketCap: 'desc' },
        include: {
          reports: {
            orderBy: { period: 'desc' },
            take: 1,
          },
        },
      }),
      db.sP500Company.count({ where }),
    ]);

    const allSectors = await db.sP500Company.findMany({
      select: { sector: true },
      distinct: ['sector'],
      orderBy: { sector: 'asc' },
    });

    const formattedCompanies = companies.map((c) => ({
      id: c.id,
      ticker: c.ticker,
      name: c.name,
      sector: c.sector,
      subSector: c.subSector,
      marketCap: c.marketCap,
      description: c.description,
      lastFiling: c.lastFiling,
      latestReport: c.reports[0]
        ? {
            quarter: c.reports[0].quarter,
            period: c.reports[0].period,
            revenue: c.reports[0].revenue,
            netIncome: c.reports[0].netIncome,
            eps: c.reports[0].eps,
            revenueGrowth: c.reports[0].revenueGrowth,
            earningsGrowth: c.reports[0].earningsGrowth,
          }
        : null,
    }));

    return NextResponse.json({
      companies: formattedCompanies,
      total,
      page,
      totalPages: Math.ceil(total / limit),
      sectors: allSectors.map((s) => s.sector),
    });
  } catch (error) {
    console.error('Error fetching companies:', error);
    return NextResponse.json(
      { error: 'Failed to fetch companies' },
      { status: 500 }
    );
  }
}