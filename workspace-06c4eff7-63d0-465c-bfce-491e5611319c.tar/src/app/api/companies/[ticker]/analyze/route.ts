import { db } from '@/lib/db';
import ZAI from 'z-ai-web-dev-sdk';
import { NextRequest, NextResponse } from 'next/server';

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ ticker: string }> }
) {
  try {
    const { ticker } = await params;
    const body = await request.json();
    const { email } = body;

    if (!email) {
      return NextResponse.json({ error: 'Email is required' }, { status: 400 });
    }

    const signup = await db.emailSignup.findUnique({ where: { email } });
    if (!signup) {
      return NextResponse.json(
        { error: 'Please sign up first to access analysis' },
        { status: 403 }
      );
    }

    const company = await db.sP500Company.findUnique({
      where: { ticker: ticker.toUpperCase() },
      include: {
        reports: { orderBy: { period: 'desc' }, take: 2 },
      },
    });

    if (!company) {
      return NextResponse.json({ error: 'Company not found' }, { status: 404 });
    }

    const zai = await ZAI.create();

    // Search for the company's latest SEC filing
    const searchQuery = `${company.ticker} ${company.name} 2025 10-Q quarterly earnings SEC filing`;
    const searchResults = await zai.functions.invoke('web_search', {
      query: searchQuery,
      num: 5,
    });

    let filingContent = '';
    const sources: string[] = [];

    // Try to read the most relevant SEC filing
    for (const result of searchResults) {
      if (
        result.url &&
        (result.url.includes('sec.gov') ||
          result.url.includes('investor') ||
          result.url.includes('ir.'))
      ) {
        try {
          const pageResult = await zai.functions.invoke('page_reader', {
            url: result.url,
          });
          filingContent = pageResult.data?.html || '';
          sources.push(result.url);
          break;
        } catch {
          continue;
        }
      }
    }

    // If no SEC filing was readable, use search snippets
    if (!filingContent) {
      filingContent = searchResults
        .slice(0, 3)
        .map(
          (r: { name: string; snippet: string; url: string }) =>
            `[${r.name}] ${r.snippet}\nSource: ${r.url}`
        )
        .join('\n\n');
      sources.push(...searchResults.slice(0, 3).map((r: { url: string }) => r.url));
    }

    const existingData = company.reports
      .map((r) => {
        return `Quarter: ${r.quarter} (Period: ${r.period})
Revenue: ${r.revenue || 'N/A'} | Net Income: ${r.netIncome || 'N/A'} | EPS: ${r.eps || 'N/A'}
Gross Margin: ${r.grossMargin || 'N/A'} | Operating Margin: ${r.operatingMargin || 'N/A'} | Net Margin: ${r.netMargin || 'N/A'}
Revenue Growth: ${r.revenueGrowth || 'N/A'} | Earnings Growth: ${r.earningsGrowth || 'N/A'}
Free Cash Flow: ${r.freeCashFlow || 'N/A'} | Total Debt: ${r.totalDebt || 'N/A'}
Return on Equity: ${r.returnOnEquity || 'N/A'}`;
      })
      .join('\n\n');

    const systemPrompt = `You are a senior financial analyst at a top Wall Street firm specializing in SEC filing analysis. You have 25+ years of experience analyzing S&P 500 companies. Your analysis is thorough, data-driven, and provides actionable insights for institutional investors. Always cite specific numbers and percentages. Be objective and balanced in your assessment.`;

    const userPrompt = `Analyze the latest quarterly results for ${company.name} (${company.ticker}).

COMPANY OVERVIEW:
${company.description}
Sector: ${company.sector} | Sub-Sector: ${company.subSector}
Market Cap: ${company.marketCap} | Headquarters: ${company.headquarters}
Employees: ${company.employees?.toLocaleString() || 'N/A'}

EXISTING QUARTERLY DATA:
${existingData}

LATEST SEC FILING INFORMATION:
${filingContent.substring(0, 4000)}

Provide a comprehensive quarterly analysis covering:
1. **Revenue & Growth Analysis** - Revenue trends, growth drivers, segment breakdown
2. **Profitability Metrics** - Margins, EPS analysis, operational efficiency
3. **Balance Sheet Health** - Debt levels, cash position, capital allocation
4. **Key Risks & Concerns** - Headwinds, competitive threats, regulatory issues
5. **Management Commentary & Outlook** - Guidance, strategic initiatives, forward-looking statements
6. **Notable Changes** - vs previous quarter, new developments, one-time items

Format the analysis in clean markdown with clear sections and bullet points. Use specific numbers throughout.`;

    const completion = await zai.chat.completions.create({
      messages: [
        { role: 'assistant', content: systemPrompt },
        { role: 'user', content: userPrompt },
      ],
      thinking: { type: 'disabled' },
    });

    const analysis = completion.choices[0]?.message?.content || '';

    // Store analysis in the latest report
    if (company.reports.length > 0) {
      await db.quarterlyReport.update({
        where: { id: company.reports[0].id },
        data: { analysis },
      });
    }

    return NextResponse.json({
      analysis,
      sources,
      companyName: company.name,
      ticker: company.ticker,
    });
  } catch (error) {
    console.error('Error analyzing company:', error);
    return NextResponse.json(
      { error: 'Failed to analyze company: ' + (error instanceof Error ? error.message : 'Unknown error') },
      { status: 500 }
    );
  }
}