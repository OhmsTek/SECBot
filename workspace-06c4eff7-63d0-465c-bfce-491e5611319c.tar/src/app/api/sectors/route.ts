import { db } from '@/lib/db';
import { NextResponse } from 'next/server';

export async function GET() {
  try {
    const sectors = await db.sP500Company.groupBy({
      by: ['sector'],
      _count: { sector: true },
      orderBy: { _count: { sector: 'desc' } },
    });

    return NextResponse.json({
      sectors: sectors.map((s) => ({
        name: s.sector,
        count: s._count.sector,
      })),
    });
  } catch (error) {
    console.error('Error fetching sectors:', error);
    return NextResponse.json({ error: 'Failed to fetch sectors' }, { status: 500 });
  }
}