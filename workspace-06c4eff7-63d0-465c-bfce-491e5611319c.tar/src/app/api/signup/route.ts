import { db } from '@/lib/db';
import { NextRequest, NextResponse } from 'next/server';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { email, firstName, lastName, company, role, purpose } = body;

    if (!email || !email.includes('@')) {
      return NextResponse.json(
        { error: 'A valid email address is required' },
        { status: 400 }
      );
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      return NextResponse.json(
        { error: 'Please enter a valid email address' },
        { status: 400 }
      );
    }

    const existing = await db.emailSignup.findUnique({ where: { email } });

    if (existing) {
      return NextResponse.json({
        success: true,
        id: existing.id,
        canDownload: true,
        message: 'Welcome back! Your access is ready.',
      });
    }

    const signup = await db.emailSignup.create({
      data: {
        email: email.toLowerCase(),
        firstName: firstName || null,
        lastName: lastName || null,
        company: company || null,
        role: role || null,
        purpose: purpose || null,
        verified: true,
      },
    });

    return NextResponse.json({
      success: true,
      id: signup.id,
      canDownload: true,
      message: 'Registration successful! You can now download reports.',
    });
  } catch (error) {
    console.error('Error creating signup:', error);
    return NextResponse.json(
      { error: 'Failed to process signup' },
      { status: 500 }
    );
  }
}