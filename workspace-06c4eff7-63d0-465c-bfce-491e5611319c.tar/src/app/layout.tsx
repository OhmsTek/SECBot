import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "SEC Insight — S&P 500 Quarterly Analysis Platform",
  description: "AI-powered analysis of S&P 500 companies' quarterly results based on SEC filings. Download comprehensive reports with financial metrics, trend analysis, and expert insights.",
  keywords: ["S&P 500", "SEC filings", "quarterly results", "earnings", "financial analysis", "AI analysis", "stock analysis", "10-Q", "10-K"],
  authors: [{ name: "SEC Insight" }],
  icons: {
    icon: "https://z-cdn.chatglm.cn/z-ai/static/logo.svg",
  },
  openGraph: {
    title: "SEC Insight — S&P 500 Quarterly Analysis Platform",
    description: "AI-powered analysis of S&P 500 companies' quarterly results based on SEC filings.",
    type: "website",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}