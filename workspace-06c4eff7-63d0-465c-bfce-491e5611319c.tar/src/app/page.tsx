"use client";

import React, { useState, useEffect, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Search,
  TrendingUp,
  TrendingDown,
  FileText,
  Download,
  ArrowRight,
  ChevronDown,
  ChevronUp,
  BarChart3,
  Shield,
  Zap,
  Users,
  X,
  Loader2,
  Building2,
  DollarSign,
  PieChart,
  Sparkles,
  ExternalLink,
  ArrowLeft,
  CheckCircle2,
  Mail,
  Globe,
  Clock,
  AlertCircle,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Skeleton } from "@/components/ui/skeleton";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";

// ─── Types ───────────────────────────────────────────────────────────────────

interface Company {
  id: string;
  ticker: string;
  name: string;
  sector: string;
  subSector: string;
  marketCap: string;
  description: string | null;
  lastFiling: string | null;
  latestReport: {
    quarter: string;
    period: string;
    revenue: string | null;
    netIncome: string | null;
    eps: string | null;
    revenueGrowth: string | null;
    earningsGrowth: string | null;
  } | null;
}

interface FullCompany extends Omit<Company, "latestReport"> {
  description: string;
  headquarters: string | null;
  employees: number | null;
  website: string | null;
  reports: Report[];
}

interface Report {
  id: string;
  quarter: string;
  period: string;
  revenue: string | null;
  netIncome: string | null;
  eps: string | null;
  grossMargin: string | null;
  operatingMargin: string | null;
  netMargin: string | null;
  revenueGrowth: string | null;
  earningsGrowth: string | null;
  freeCashFlow: string | null;
  totalDebt: string | null;
  totalAssets: string | null;
  shareholdersEquity: string | null;
  returnOnEquity: string | null;
  analysis: string | null;
  highlights: string | null;
}

interface Sector {
  name: string;
  count: number;
}

type ViewState = "landing" | "browse" | "detail";

// ─── Helpers ─────────────────────────────────────────────────────────────────

function parseGrowth(val: string | null | undefined): number | null {
  if (!val) return null;
  const match = val.match(/([+-]?[\d.]+)/);
  return match ? parseFloat(match[1]) : null;
}

function formatMarketCap(mc: string): string {
  const num = parseFloat(mc);
  if (mc.endsWith("T")) return `$${num.toFixed(2)}T`;
  if (mc.endsWith("B")) return `$${num.toFixed(0)}B`;
  return mc;
}

function getGrowthColor(val: string | null): string {
  const num = parseGrowth(val);
  if (num === null) return "text-muted-foreground";
  return num >= 0 ? "text-emerald-600" : "text-red-500";
}

function getGrowthIcon(val: string | null) {
  const num = parseGrowth(val);
  if (num === null) return <span className="text-muted-foreground text-xs">—</span>;
  return num >= 0 ? (
    <TrendingUp className="h-3.5 w-3.5 text-emerald-600" />
  ) : (
    <TrendingDown className="h-3.5 w-3.5 text-red-500" />
  );
}

// ─── Component ───────────────────────────────────────────────────────────────

export default function HomePage() {
  const { toast } = useToast();
  const [view, setView] = useState<ViewState>("landing");
  const [companies, setCompanies] = useState<Company[]>([]);
  const [sectors, setSectors] = useState<Sector[]>([]);
  const [stats, setStats] = useState({ totalCompanies: 0, totalReports: 0, totalSignups: 0, sectors: 0 });
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedSector, setSelectedSector] = useState("all");
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [loading, setLoading] = useState(false);
  const [selectedCompany, setSelectedCompany] = useState<FullCompany | null>(null);
  const [detailLoading, setDetailLoading] = useState(false);

  // Signup modal
  const [showSignup, setShowSignup] = useState(false);
  const [signupForm, setSignupForm] = useState({ email: "", firstName: "", lastName: "", company: "", role: "", purpose: "" });
  const [signupLoading, setSignupLoading] = useState(false);
  const [signedUpEmail, setSignedUpEmail] = useState<string | null>(null);

  // AI Analysis
  const [analyzing, setAnalyzing] = useState(false);
  const [aiAnalysis, setAiAnalysis] = useState<string | null>(null);
  const [analysisSources, setAnalysisSources] = useState<string[]>([]);

  // Download
  const [downloading, setDownloading] = useState(false);

  // Landing search (in hero)
  const [heroSearch, setHeroSearch] = useState("");

  const fetchCompanies = useCallback(async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams();
      if (searchQuery) params.set("search", searchQuery);
      if (selectedSector !== "all") params.set("sector", selectedSector);
      params.set("page", page.toString());
      params.set("limit", "18");

      const res = await fetch(`/api/companies?${params}`);
      const data = await res.json();
      setCompanies(data.companies || []);
      setTotalPages(data.totalPages || 1);
      if (!sectors.length && data.sectors?.length) {
        setSectors(data.sectors.map((s: string) => ({ name: s, count: 0 })));
      }
    } catch {
      toast({ title: "Error", description: "Failed to fetch companies", variant: "destructive" });
    } finally {
      setLoading(false);
    }
  }, [searchQuery, selectedSector, page, sectors.length, toast]);

  const fetchSectorsAndStats = useCallback(async () => {
    try {
      const [secRes, statsRes] = await Promise.all([
        fetch("/api/sectors"),
        fetch("/api/stats"),
      ]);
      const secData = await secRes.json();
      const statsData = await statsRes.json();
      setSectors(secData.sectors || []);
      setStats(statsData);
    } catch {
      // Silent fail for stats
    }
  }, []);

  useEffect(() => {
    if (view === "browse") {
      fetchCompanies();
    }
  }, [view, fetchCompanies]);

  useEffect(() => {
    fetchSectorsAndStats();
  }, [fetchSectorsAndStats]);

  const handleHeroSearch = () => {
    if (heroSearch.trim()) {
      setSearchQuery(heroSearch.trim());
      setPage(1);
      setView("browse");
    } else {
      setView("browse");
    }
  };

  const handleCompanyClick = async (ticker: string) => {
    setDetailLoading(true);
    setAiAnalysis(null);
    setView("detail");
    try {
      const res = await fetch(`/api/companies/${ticker}`);
      const data = await res.json();
      setSelectedCompany(data.company);
      if (data.company?.reports?.[0]?.analysis) {
        setAiAnalysis(data.company.reports[0].analysis);
      }
    } catch {
      toast({ title: "Error", description: "Failed to load company details", variant: "destructive" });
    } finally {
      setDetailLoading(false);
    }
  };

  const handleAnalyze = async () => {
    if (!selectedCompany || !signedUpEmail) {
      setShowSignup(true);
      return;
    }
    setAnalyzing(true);
    try {
      const res = await fetch(`/api/companies/${selectedCompany.ticker}/analyze`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email: signedUpEmail }),
      });
      const data = await res.json();
      if (data.error) {
        toast({ title: "Analysis Error", description: data.error, variant: "destructive" });
      } else {
        setAiAnalysis(data.analysis);
        setAnalysisSources(data.sources || []);
        toast({ title: "Analysis Complete", description: "AI has analyzed the latest SEC filings" });
      }
    } catch {
      toast({ title: "Error", description: "Failed to generate analysis", variant: "destructive" });
    } finally {
      setAnalyzing(false);
    }
  };

  const handleSignup = async () => {
    if (!signupForm.email) {
      toast({ title: "Email Required", description: "Please enter your email address", variant: "destructive" });
      return;
    }
    setSignupLoading(true);
    try {
      const res = await fetch("/api/signup", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(signupForm),
      });
      const data = await res.json();
      if (data.success) {
        setSignedUpEmail(signupForm.email);
        setShowSignup(false);
        toast({ title: "Success", description: data.message });
      } else {
        toast({ title: "Error", description: data.error, variant: "destructive" });
      }
    } catch {
      toast({ title: "Error", description: "Signup failed", variant: "destructive" });
    } finally {
      setSignupLoading(false);
    }
  };

  const handleDownload = async () => {
    if (!signedUpEmail) {
      setShowSignup(true);
      return;
    }
    if (!selectedCompany) return;
    setDownloading(true);
    try {
      const res = await fetch("/api/download", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email: signedUpEmail, companyTicker: selectedCompany.ticker }),
      });
      const data = await res.json();
      if (data.success) {
        window.open(data.downloadUrl, "_blank");
        toast({ title: "Report Ready", description: "Your report has been generated" });
      } else {
        toast({ title: "Error", description: data.error, variant: "destructive" });
      }
    } catch {
      toast({ title: "Error", description: "Download failed", variant: "destructive" });
    } finally {
      setDownloading(false);
    }
  };

  // ─── RENDER: Landing Hero ───────────────────────────────────────────────

  const renderHero = () => (
    <div className="relative min-h-screen flex flex-col">
      {/* Nav */}
      <nav className="absolute top-0 left-0 right-0 z-10 flex items-center justify-between px-6 md:px-12 py-5">
        <div className="flex items-center gap-2">
          <div className="h-9 w-9 rounded-lg bg-emerald-600 flex items-center justify-center">
            <BarChart3 className="h-5 w-5 text-white" />
          </div>
          <span className="text-lg font-bold tracking-tight">SEC Insight</span>
        </div>
        <div className="flex items-center gap-3">
          {signedUpEmail && (
            <Badge variant="secondary" className="hidden sm:flex items-center gap-1.5">
              <CheckCircle2 className="h-3 w-3 text-emerald-600" />
              {signedUpEmail}
            </Badge>
          )}
          <Button
            variant="outline"
            size="sm"
            onClick={() => setView("browse")}
          >
            Browse S&P 500
          </Button>
          {!signedUpEmail && (
            <Button size="sm" className="bg-emerald-600 hover:bg-emerald-700" onClick={() => setShowSignup(true)}>
              Get Access
            </Button>
          )}
        </div>
      </nav>

      {/* Hero Content */}
      <div className="relative flex-1 flex items-center">
        <div className="absolute inset-0 z-0">
          <img
            src="/hero-bg.png"
            alt=""
            className="w-full h-full object-cover opacity-30"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-black/80 via-black/60 to-transparent" />
          <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent" />
        </div>

        <div className="relative z-10 px-6 md:px-12 lg:px-20 max-w-4xl py-32">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7 }}
          >
            <Badge variant="secondary" className="mb-6 text-emerald-400 border-emerald-800 bg-emerald-950/50 backdrop-blur-sm">
              <Sparkles className="h-3 w-3 mr-1.5" />
              AI-Powered SEC Filing Analysis
            </Badge>

            <h1 className="text-4xl sm:text-5xl md:text-6xl font-extrabold text-white leading-[1.1] tracking-tight mb-6">
              Decode S&P 500
              <br />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 to-emerald-200">
                Quarterly Results
              </span>
            </h1>

            <p className="text-lg md:text-xl text-gray-300 max-w-2xl mb-10 leading-relaxed">
              Get AI-powered analysis of quarterly earnings based on SEC filings.
              Comprehensive financial metrics, trend analysis, and actionable insights
              for every S&P 500 company.
            </p>

            {/* Search Bar */}
            <div className="flex flex-col sm:flex-row gap-3 max-w-xl mb-8">
              <div className="relative flex-1">
                <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4.5 w-4.5 text-gray-400" />
                <Input
                  placeholder="Search by ticker or company name..."
                  value={heroSearch}
                  onChange={(e) => setHeroSearch(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && handleHeroSearch()}
                  className="pl-11 h-12 bg-white/10 border-white/20 text-white placeholder:text-gray-400 focus:bg-white/15 backdrop-blur-sm text-base"
                />
              </div>
              <Button
                size="lg"
                className="h-12 bg-emerald-600 hover:bg-emerald-700 text-white px-8 text-base font-semibold"
                onClick={handleHeroSearch}
              >
                Analyze
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </div>

            {/* Quick access examples */}
            <div className="flex flex-wrap gap-2">
              {["AAPL", "NVDA", "MSFT", "TSLA", "META", "AMZN"].map((t) => (
                <button
                  key={t}
                  onClick={() => { setSearchQuery(t); setPage(1); setView("browse"); }}
                  className="px-3 py-1.5 text-xs font-medium rounded-full bg-white/10 text-gray-300 hover:bg-white/20 hover:text-white transition-colors border border-white/10"
                >
                  {t}
                </button>
              ))}
            </div>
          </motion.div>
        </div>
      </div>

      {/* Stats Bar */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.5, duration: 0.5 }}
        className="relative z-10 bg-black/40 backdrop-blur-md border-t border-white/10"
      >
        <div className="max-w-7xl mx-auto px-6 md:px-12 py-6 grid grid-cols-2 md:grid-cols-4 gap-6">
          {[
            { icon: Building2, label: "S&P 500 Companies", value: `${stats.totalCompanies}+` },
            { icon: FileText, label: "Quarterly Reports", value: `${stats.totalReports}+` },
            { icon: Sparkles, label: "AI Analysis", value: "SEC-Based" },
            { icon: Users, label: "Analysts Served", value: `${stats.totalSignups}` },
          ].map(({ icon: Icon, label, value }) => (
            <div key={label} className="flex items-center gap-3">
              <div className="h-10 w-10 rounded-lg bg-emerald-600/20 flex items-center justify-center shrink-0">
                <Icon className="h-5 w-5 text-emerald-400" />
              </div>
              <div>
                <div className="text-white font-bold text-lg leading-tight">{value}</div>
                <div className="text-gray-400 text-xs">{label}</div>
              </div>
            </div>
          ))}
        </div>
      </motion.div>

      {/* Features Section */}
      <section className="bg-background py-20 px-6 md:px-12">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-14">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Why SEC Insight?</h2>
            <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
              Professional-grade quarterly analysis powered by AI, built on real SEC filings data.
            </p>
          </div>
          <div className="grid md:grid-cols-3 gap-6">
            {[
              {
                icon: FileText,
                title: "SEC Filing Based",
                desc: "Analysis built on actual 10-Q and 10-K filings from EDGAR. Real data, not estimates or projections.",
              },
              {
                icon: Sparkles,
                title: "AI-Powered Insights",
                desc: "Advanced LLM analysis extracts key metrics, identifies trends, and provides actionable insights.",
              },
              {
                icon: Download,
                title: "Downloadable Reports",
                desc: "Generate professional PDF reports for any S&P 500 company. Perfect for investment research.",
              },
              {
                icon: Shield,
                title: "Comprehensive Metrics",
                desc: "Revenue, earnings, margins, cash flow, balance sheet health, and 15+ financial KPIs tracked quarterly.",
              },
              {
                icon: Zap,
                title: "Real-Time Updates",
                desc: "Reports updated as new SEC filings are released. Stay ahead of earnings season with timely analysis.",
              },
              {
                icon: BarChart3,
                title: "Sector Intelligence",
                desc: "Filter and compare across all 11 GICS sectors. Identify sector-wide trends and outperformers.",
              },
            ].map(({ icon: Icon, title, desc }) => (
              <Card key={title} className="group hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="h-11 w-11 rounded-lg bg-emerald-50 flex items-center justify-center mb-2 group-hover:bg-emerald-100 transition-colors">
                    <Icon className="h-5.5 w-5.5 text-emerald-600" />
                  </div>
                  <CardTitle className="text-lg">{title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground leading-relaxed">{desc}</p>
                </CardContent>
              </Card>
            ))}
          </div>
          <div className="text-center mt-12">
            <Button
              size="lg"
              className="bg-emerald-600 hover:bg-emerald-700 text-white px-8"
              onClick={() => setView("browse")}
            >
              Explore All S&P 500 Companies
              <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="bg-muted/40 py-20 px-6 md:px-12">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-3xl font-bold text-center mb-14">How It Works</h2>
          <div className="grid md:grid-cols-3 gap-8">
            {[
              { step: "01", title: "Search & Select", desc: "Browse or search from 500+ S&P 500 companies. Filter by sector, market cap, or performance." },
              { step: "02", title: "AI Analysis", desc: "Our AI reads the latest SEC 10-Q filing, extracts financials, and generates comprehensive analysis." },
              { step: "03", title: "Download Report", desc: "Sign up with your email and download professional quarterly analysis reports in PDF format." },
            ].map(({ step, title, desc }) => (
              <div key={step} className="text-center">
                <div className="text-5xl font-extrabold text-emerald-100 mb-3">{step}</div>
                <h3 className="text-lg font-bold mb-2">{title}</h3>
                <p className="text-sm text-muted-foreground">{desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );

  // ─── RENDER: Browse Companies ───────────────────────────────────────────

  const renderBrowse = () => (
    <div className="min-h-screen flex flex-col">
      {/* Top Bar */}
      <header className="sticky top-0 z-30 bg-background/80 backdrop-blur-md border-b">
        <div className="max-w-7xl mx-auto px-4 md:px-8 h-16 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3 shrink-0">
            <Button variant="ghost" size="sm" onClick={() => setView("landing")} className="gap-1.5 text-muted-foreground hover:text-foreground">
              <ArrowLeft className="h-4 w-4" />
              <span className="hidden sm:inline">Home</span>
            </Button>
            <Separator orientation="vertical" className="h-6" />
            <div className="flex items-center gap-2">
              <div className="h-7 w-7 rounded-md bg-emerald-600 flex items-center justify-center">
                <BarChart3 className="h-4 w-4 text-white" />
              </div>
              <span className="font-bold text-sm hidden sm:inline">SEC Insight</span>
            </div>
          </div>

          <div className="flex-1 max-w-md">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search companies..."
                value={searchQuery}
                onChange={(e) => { setSearchQuery(e.target.value); setPage(1); }}
                className="pl-9 h-9"
              />
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <Select value={selectedSector} onValueChange={(v) => { setSelectedSector(v); setPage(1); }}>
              <SelectTrigger className="w-[160px] h-9">
                <PieChart className="h-3.5 w-3.5 mr-1.5 text-muted-foreground" />
                <SelectValue placeholder="All Sectors" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Sectors</SelectItem>
                {sectors.map((s) => (
                  <SelectItem key={s.name} value={s.name}>
                    {s.name} ({s.count})
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 max-w-7xl mx-auto w-full px-4 md:px-8 py-8">
        {/* Sector Filter Pills */}
        <div className="flex gap-2 mb-6 overflow-x-auto pb-2 scrollbar-none">
          {sectors.slice(0, 11).map((s) => (
            <button
              key={s.name}
              onClick={() => { setSelectedSector(selectedSector === s.name ? "all" : s.name); setPage(1); }}
              className={`shrink-0 px-3.5 py-1.5 rounded-full text-xs font-medium transition-colors ${
                selectedSector === s.name
                  ? "bg-emerald-600 text-white"
                  : "bg-secondary text-secondary-foreground hover:bg-secondary/80"
              }`}
            >
              {s.name} ({s.count})
            </button>
          ))}
        </div>

        {/* Results */}
        {loading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {Array.from({ length: 9 }).map((_, i) => (
              <Skeleton key={i} className="h-40 rounded-xl" />
            ))}
          </div>
        ) : companies.length === 0 ? (
          <div className="text-center py-20">
            <AlertCircle className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
            <h3 className="text-lg font-semibold mb-2">No companies found</h3>
            <p className="text-muted-foreground text-sm mb-4">Try adjusting your search or filter criteria</p>
            <Button variant="outline" onClick={() => { setSearchQuery(""); setSelectedSector("all"); setPage(1); }}>
              Clear Filters
            </Button>
          </div>
        ) : (
          <>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {companies.map((c) => (
                <motion.div
                  key={c.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.2 }}
                >
                  <Card
                    className="cursor-pointer hover:shadow-md hover:border-emerald-200 transition-all group h-full"
                    onClick={() => handleCompanyClick(c.ticker)}
                  >
                    <CardContent className="p-5">
                      <div className="flex items-start justify-between mb-3">
                        <div>
                          <div className="flex items-center gap-2 mb-1">
                            <span className="text-lg font-bold">{c.ticker}</span>
                            <Badge variant="outline" className="text-[10px] px-1.5 py-0">{c.sector.split(" ").slice(0, 2).join(" ")}</Badge>
                          </div>
                          <p className="text-sm text-muted-foreground line-clamp-1">{c.name}</p>
                        </div>
                        <span className="text-sm font-semibold text-foreground">{formatMarketCap(c.marketCap)}</span>
                      </div>

                      {c.latestReport ? (
                        <div className="grid grid-cols-2 gap-2 text-xs">
                          <div className="bg-muted/50 rounded-md px-2.5 py-2">
                            <div className="text-muted-foreground mb-0.5">Revenue</div>
                            <div className="font-semibold">{c.latestReport.revenue || "—"}</div>
                          </div>
                          <div className="bg-muted/50 rounded-md px-2.5 py-2">
                            <div className="text-muted-foreground mb-0.5">EPS</div>
                            <div className="font-semibold">{c.latestReport.eps || "—"}</div>
                          </div>
                          <div className="bg-muted/50 rounded-md px-2.5 py-2">
                            <div className="text-muted-foreground mb-0.5">Rev Growth</div>
                            <div className={`font-semibold flex items-center gap-1 ${getGrowthColor(c.latestReport.revenueGrowth)}`}>
                              {getGrowthIcon(c.latestReport.revenueGrowth)}
                              {c.latestReport.revenueGrowth || "—"}
                            </div>
                          </div>
                          <div className="bg-muted/50 rounded-md px-2.5 py-2">
                            <div className="text-muted-foreground mb-0.5">Earnings</div>
                            <div className={`font-semibold flex items-center gap-1 ${getGrowthColor(c.latestReport.earningsGrowth)}`}>
                              {getGrowthIcon(c.latestReport.earningsGrowth)}
                              {c.latestReport.earningsGrowth || "—"}
                            </div>
                          </div>
                        </div>
                      ) : (
                        <div className="text-xs text-muted-foreground bg-muted/50 rounded-md px-3 py-6 text-center">
                          <FileText className="h-4 w-4 mx-auto mb-1 opacity-50" />
                          Report pending — click to view
                        </div>
                      )}

                      <div className="flex items-center justify-between mt-3 pt-3 border-t">
                        <span className="text-[11px] text-muted-foreground flex items-center gap-1">
                          <Clock className="h-3 w-3" />
                          {c.latestReport?.quarter || "No data"}
                        </span>
                        <span className="text-xs text-emerald-600 font-medium opacity-0 group-hover:opacity-100 transition-opacity flex items-center gap-1">
                          View Details <ChevronRight className="h-3 w-3" />
                        </span>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>

            {/* Pagination */}
            {totalPages > 1 && (
              <div className="flex items-center justify-center gap-2 mt-10">
                <Button
                  variant="outline"
                  size="sm"
                  disabled={page === 1}
                  onClick={() => setPage((p) => p - 1)}
                >
                  Previous
                </Button>
                {Array.from({ length: Math.min(totalPages, 5) }, (_, i) => {
                  const p = i + 1;
                  return (
                    <Button
                      key={p}
                      variant={page === p ? "default" : "outline"}
                      size="sm"
                      className={page === p ? "bg-emerald-600 hover:bg-emerald-700" : ""}
                      onClick={() => setPage(p)}
                    >
                      {p}
                    </Button>
                  );
                })}
                {totalPages > 5 && <span className="text-muted-foreground text-sm px-1">...</span>}
                <Button
                  variant="outline"
                  size="sm"
                  disabled={page === totalPages}
                  onClick={() => setPage((p) => p + 1)}
                >
                  Next
                </Button>
              </div>
            )}
          </>
        )}
      </main>
    </div>
  );

  // ─── RENDER: Company Detail ─────────────────────────────────────────────

  const renderDetail = () => {
    if (detailLoading) {
      return (
        <div className="min-h-screen flex items-center justify-center">
          <div className="text-center">
            <Loader2 className="h-8 w-8 animate-spin mx-auto mb-4 text-emerald-600" />
            <p className="text-muted-foreground">Loading company data...</p>
          </div>
        </div>
      );
    }

    if (!selectedCompany) return null;

    const latest = selectedCompany.reports[0];
    const highlights = latest?.highlights ? JSON.parse(latest.highlights) as string[] : [];

    return (
      <div className="min-h-screen flex flex-col">
        {/* Header */}
        <header className="sticky top-0 z-30 bg-background/80 backdrop-blur-md border-b">
          <div className="max-w-6xl mx-auto px-4 md:px-8 h-14 flex items-center justify-between">
            <Button variant="ghost" size="sm" onClick={() => { setView("browse"); setSelectedCompany(null); setAiAnalysis(null); }} className="gap-1.5">
              <ArrowLeft className="h-4 w-4" />
              Back to Companies
            </Button>
            <div className="flex items-center gap-2">
              <Button variant="outline" size="sm" onClick={handleDownload} disabled={downloading} className="gap-1.5">
                {downloading ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Download className="h-3.5 w-3.5" />}
                Download PDF
              </Button>
              <Button size="sm" onClick={handleAnalyze} disabled={analyzing} className="gap-1.5 bg-emerald-600 hover:bg-emerald-700">
                {analyzing ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Sparkles className="h-3.5 w-3.5" />}
                {aiAnalysis ? "Re-Analyze" : "AI Analysis"}
              </Button>
            </div>
          </div>
        </header>

        <main className="flex-1 max-w-6xl mx-auto w-full px-4 md:px-8 py-8">
          {/* Company Header */}
          <div className="mb-8">
            <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4 mb-4">
              <div>
                <div className="flex items-center gap-3 mb-2">
                  <h1 className="text-3xl font-extrabold">{selectedCompany.name}</h1>
                  <Badge className="bg-emerald-100 text-emerald-800 hover:bg-emerald-100 text-sm px-3 py-1 font-bold">
                    {selectedCompany.ticker}
                  </Badge>
                </div>
                <div className="flex flex-wrap items-center gap-3 text-sm text-muted-foreground">
                  <span className="flex items-center gap-1"><PieChart className="h-3.5 w-3.5" /> {selectedCompany.sector}</span>
                  <span>·</span>
                  <span>{selectedCompany.subSector}</span>
                  <span>·</span>
                  <span className="font-semibold text-foreground">{formatMarketCap(selectedCompany.marketCap)}</span>
                </div>
              </div>
              <div className="flex items-center gap-4 text-sm text-muted-foreground shrink-0">
                {selectedCompany.headquarters && <span className="flex items-center gap-1"><Globe className="h-3.5 w-3.5" /> {selectedCompany.headquarters}</span>}
                {selectedCompany.employees && <span className="flex items-center gap-1"><Users className="h-3.5 w-3.5" /> {selectedCompany.employees.toLocaleString()} employees</span>}
              </div>
            </div>
            <p className="text-sm text-muted-foreground max-w-3xl leading-relaxed">{selectedCompany.description}</p>
          </div>

          <Tabs defaultValue="financials" className="space-y-6">
            <TabsList className="grid w-full max-w-md grid-cols-3">
              <TabsTrigger value="financials" className="text-sm">Financials</TabsTrigger>
              <TabsTrigger value="analysis" className="text-sm">AI Analysis</TabsTrigger>
              <TabsTrigger value="quarters" className="text-sm">All Quarters</TabsTrigger>
            </TabsList>

            {/* ─── Financials Tab ─── */}
            <TabsContent value="financials" className="space-y-6">
              {latest ? (
                <>
                  {/* Key Metrics Grid */}
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                    {[
                      { label: "Revenue", value: latest.revenue, icon: DollarSign },
                      { label: "Net Income", value: latest.netIncome, icon: DollarSign },
                      { label: "EPS", value: latest.eps, icon: DollarSign },
                      { label: "Rev Growth", value: latest.revenueGrowth, icon: TrendingUp },
                    ].map(({ label, value, icon: Icon }) => (
                      <Card key={label}>
                        <CardContent className="p-4">
                          <div className="flex items-center gap-1.5 mb-1">
                            <Icon className="h-3.5 w-3.5 text-muted-foreground" />
                            <span className="text-xs text-muted-foreground">{label}</span>
                          </div>
                          <div className={`text-xl font-bold ${label.includes("Growth") ? getGrowthColor(value) : ""}`}>
                            {value || "N/A"}
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>

                  {/* Profitability */}
                  <Card>
                    <CardHeader className="pb-3">
                      <CardTitle className="text-base">Profitability Metrics — {latest.quarter}</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
                        {[
                          { label: "Gross Margin", value: latest.grossMargin },
                          { label: "Operating Margin", value: latest.operatingMargin },
                          { label: "Net Margin", value: latest.netMargin },
                          { label: "Earnings Growth", value: latest.earningsGrowth },
                          { label: "Free Cash Flow", value: latest.freeCashFlow },
                          { label: "Return on Equity", value: latest.returnOnEquity },
                        ].map(({ label, value }) => (
                          <div key={label} className="flex items-center justify-between py-2 border-b last:border-0">
                            <span className="text-sm text-muted-foreground">{label}</span>
                            <span className={`text-sm font-semibold ${label.includes("Growth") ? getGrowthColor(value) : ""}`}>
                              {value || "N/A"}
                            </span>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>

                  {/* Balance Sheet */}
                  <Card>
                    <CardHeader className="pb-3">
                      <CardTitle className="text-base">Balance Sheet — {latest.quarter}</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
                        {[
                          { label: "Total Debt", value: latest.totalDebt },
                          { label: "Total Assets", value: latest.totalAssets },
                          { label: "Shareholders' Equity", value: latest.shareholdersEquity },
                        ].map(({ label, value }) => (
                          <div key={label} className="flex items-center justify-between py-2 border-b last:border-0">
                            <span className="text-sm text-muted-foreground">{label}</span>
                            <span className="text-sm font-semibold">{value || "N/A"}</span>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>

                  {/* Key Highlights */}
                  {highlights.length > 0 && (
                    <Card className="border-emerald-200 bg-emerald-50/50">
                      <CardHeader className="pb-3">
                        <CardTitle className="text-base flex items-center gap-2">
                          <Sparkles className="h-4 w-4 text-emerald-600" />
                          Key Highlights
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <ul className="space-y-2">
                          {highlights.map((h, i) => (
                            <li key={i} className="flex items-start gap-2 text-sm">
                              <CheckCircle2 className="h-4 w-4 text-emerald-600 mt-0.5 shrink-0" />
                              <span>{h}</span>
                            </li>
                          ))}
                        </ul>
                      </CardContent>
                    </Card>
                  )}

                  {/* Analysis Summary */}
                  {latest.analysis && (
                    <Card>
                      <CardHeader className="pb-3">
                        <CardTitle className="text-base flex items-center gap-2">
                          <FileText className="h-4 w-4 text-emerald-600" />
                          Quarterly Analysis — {latest.quarter}
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="prose prose-sm max-w-none text-sm leading-relaxed whitespace-pre-wrap text-foreground">
                          {latest.analysis}
                        </div>
                      </CardContent>
                    </Card>
                  )}
                </>
              ) : (
                <div className="text-center py-16 bg-muted/30 rounded-xl">
                  <FileText className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
                  <h3 className="text-lg font-semibold mb-2">No Reports Available</h3>
                  <p className="text-muted-foreground text-sm mb-6">
                    Quarterly reports for this company are being processed. Use the AI Analysis button to fetch and analyze the latest SEC filing.
                  </p>
                  <Button onClick={handleAnalyze} disabled={analyzing} className="bg-emerald-600 hover:bg-emerald-700 gap-2">
                    {analyzing ? <Loader2 className="h-4 w-4 animate-spin" /> : <Sparkles className="h-4 w-4" />}
                    Generate Analysis
                  </Button>
                </div>
              )}
            </TabsContent>

            {/* ─── AI Analysis Tab ─── */}
            <TabsContent value="analysis">
              {analyzing ? (
                <div className="flex flex-col items-center justify-center py-20">
                  <Loader2 className="h-10 w-10 animate-spin text-emerald-600 mb-4" />
                  <h3 className="text-lg font-semibold mb-2">Analyzing SEC Filings</h3>
                  <p className="text-sm text-muted-foreground text-center max-w-md">
                    Our AI is reading the latest 10-Q/10-K filing for {selectedCompany.name},
                    extracting financial data, and generating a comprehensive analysis...
                  </p>
                </div>
              ) : aiAnalysis ? (
                <Card>
                  <CardHeader className="pb-3">
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-base flex items-center gap-2">
                        <Sparkles className="h-4 w-4 text-emerald-600" />
                        AI-Powered SEC Filing Analysis
                      </CardTitle>
                      <Badge variant="outline" className="text-xs">Generated by AI</Badge>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="prose prose-sm max-w-none text-sm leading-relaxed whitespace-pre-wrap text-foreground">
                      {aiAnalysis}
                    </div>
                    {analysisSources.length > 0 && (
                      <div className="mt-6 pt-4 border-t">
                        <p className="text-xs text-muted-foreground mb-2">Sources:</p>
                        <div className="flex flex-wrap gap-2">
                          {analysisSources.map((s, i) => (
                            <a
                              key={i}
                              href={s}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="text-xs text-emerald-600 hover:underline flex items-center gap-1 break-all"
                            >
                              <ExternalLink className="h-3 w-3 shrink-0" />
                              {s.length > 60 ? s.substring(0, 60) + "..." : s}
                            </a>
                          ))}
                        </div>
                      </div>
                    )}
                  </CardContent>
                </Card>
              ) : (
                <div className="text-center py-20 bg-muted/30 rounded-xl">
                  <Sparkles className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
                  <h3 className="text-lg font-semibold mb-2">Generate AI Analysis</h3>
                  <p className="text-muted-foreground text-sm mb-6 max-w-md mx-auto">
                    Click below to have our AI analyze the latest SEC filing for {selectedCompany.name}.
                    {!signedUpEmail && " You'll need to sign up with your email first."}
                  </p>
                  <Button onClick={handleAnalyze} className="bg-emerald-600 hover:bg-emerald-700 gap-2">
                    <Sparkles className="h-4 w-4" />
                    Analyze {selectedCompany.ticker} SEC Filing
                  </Button>
                </div>
              )}
            </TabsContent>

            {/* ─── All Quarters Tab ─── */}
            <TabsContent value="quarters">
              {selectedCompany.reports.length > 0 ? (
                <Card>
                  <CardContent className="p-0">
                    <div className="overflow-x-auto">
                      <table className="w-full text-sm">
                        <thead>
                          <tr className="border-b bg-muted/50">
                            <th className="text-left px-4 py-3 font-semibold">Quarter</th>
                            <th className="text-right px-4 py-3 font-semibold">Revenue</th>
                            <th className="text-right px-4 py-3 font-semibold">Net Income</th>
                            <th className="text-right px-4 py-3 font-semibold">EPS</th>
                            <th className="text-right px-4 py-3 font-semibold">Gross Margin</th>
                            <th className="text-right px-4 py-3 font-semibold">Rev Growth</th>
                            <th className="text-right px-4 py-3 font-semibold">EPS Growth</th>
                            <th className="text-right px-4 py-3 font-semibold">FCF</th>
                          </tr>
                        </thead>
                        <tbody>
                          {selectedCompany.reports.map((r) => (
                            <tr key={r.id} className="border-b last:border-0 hover:bg-muted/30">
                              <td className="px-4 py-3 font-medium">{r.quarter}</td>
                              <td className="text-right px-4 py-3">{r.revenue || "—"}</td>
                              <td className="text-right px-4 py-3">{r.netIncome || "—"}</td>
                              <td className="text-right px-4 py-3">{r.eps || "—"}</td>
                              <td className="text-right px-4 py-3">{r.grossMargin || "—"}</td>
                              <td className={`text-right px-4 py-3 font-medium ${getGrowthColor(r.revenueGrowth)}`}>
                                {r.revenueGrowth || "—"}
                              </td>
                              <td className={`text-right px-4 py-3 font-medium ${getGrowthColor(r.earningsGrowth)}`}>
                                {r.earningsGrowth || "—"}
                              </td>
                              <td className="text-right px-4 py-3">{r.freeCashFlow || "—"}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </CardContent>
                </Card>
              ) : (
                <div className="text-center py-16 text-muted-foreground">
                  <p>No quarterly report data available yet.</p>
                </div>
              )}
            </TabsContent>
          </Tabs>
        </main>
      </div>
    );
  };

  // ─── RENDER: Footer ──────────────────────────────────────────────────────

  const renderFooter = () => (
    <footer className="bg-muted/50 border-t mt-auto">
      <div className="max-w-7xl mx-auto px-6 md:px-12 py-10">
        <div className="grid md:grid-cols-4 gap-8 mb-8">
          <div className="md:col-span-2">
            <div className="flex items-center gap-2 mb-3">
              <div className="h-8 w-8 rounded-lg bg-emerald-600 flex items-center justify-center">
                <BarChart3 className="h-4 w-4 text-white" />
              </div>
              <span className="font-bold">SEC Insight</span>
            </div>
            <p className="text-sm text-muted-foreground max-w-md leading-relaxed">
              AI-powered quarterly analysis of S&P 500 companies based on SEC filings.
              Professional-grade financial intelligence for institutional and retail investors.
            </p>
          </div>
          <div>
            <h4 className="font-semibold text-sm mb-3">Platform</h4>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li><button onClick={() => setView("browse")} className="hover:text-foreground transition-colors">Browse Companies</button></li>
              <li><button onClick={() => setShowSignup(true)} className="hover:text-foreground transition-colors">Get Access</button></li>
            </ul>
          </div>
          <div>
            <h4 className="font-semibold text-sm mb-3">Legal</h4>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li>Privacy Policy</li>
              <li>Terms of Service</li>
              <li>Disclaimer</li>
            </ul>
          </div>
        </div>
        <Separator className="mb-6" />
        <div className="flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-muted-foreground">
          <p>&copy; {new Date().getFullYear()} SEC Insight. All rights reserved.</p>
          <p>This platform does not constitute investment advice. Data sourced from SEC EDGAR.</p>
        </div>
      </div>
    </footer>
  );

  // ─── RENDER: Signup Modal ───────────────────────────────────────────────

  const renderSignupModal = () => (
    <Dialog open={showSignup} onOpenChange={setShowSignup}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Mail className="h-5 w-5 text-emerald-600" />
            Get Access to Reports
          </DialogTitle>
          <DialogDescription>
            Enter your email to access AI-powered quarterly analysis and download PDF reports for any S&P 500 company.
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-4 py-2">
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-2">
              <Label htmlFor="firstName">First Name</Label>
              <Input
                id="firstName"
                placeholder="John"
                value={signupForm.firstName}
                onChange={(e) => setSignupForm({ ...signupForm, firstName: e.target.value })}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="lastName">Last Name</Label>
              <Input
                id="lastName"
                placeholder="Smith"
                value={signupForm.lastName}
                onChange={(e) => setSignupForm({ ...signupForm, lastName: e.target.value })}
              />
            </div>
          </div>
          <div className="space-y-2">
            <Label htmlFor="email">Email Address <span className="text-red-500">*</span></Label>
            <Input
              id="email"
              type="email"
              placeholder="john@company.com"
              value={signupForm.email}
              onChange={(e) => setSignupForm({ ...signupForm, email: e.target.value })}
              onKeyDown={(e) => e.key === "Enter" && handleSignup()}
            />
            <p className="text-[11px] text-muted-foreground">Your email is kept private and used solely for report access.</p>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-2">
              <Label htmlFor="company">Company</Label>
              <Input
                id="company"
                placeholder="Acme Corp"
                value={signupForm.company}
                onChange={(e) => setSignupForm({ ...signupForm, company: e.target.value })}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="role">Role</Label>
              <Input
                id="role"
                placeholder="Analyst"
                value={signupForm.role}
                onChange={(e) => setSignupForm({ ...signupForm, role: e.target.value })}
              />
            </div>
          </div>
          <div className="space-y-2">
            <Label htmlFor="purpose">Purpose <span className="text-muted-foreground text-xs font-normal">(optional)</span></Label>
            <Textarea
              id="purpose"
              placeholder="What do you plan to use these reports for?"
              value={signupForm.purpose}
              onChange={(e) => setSignupForm({ ...signupForm, purpose: e.target.value })}
              rows={2}
            />
          </div>
          <Button
            className="w-full bg-emerald-600 hover:bg-emerald-700"
            onClick={handleSignup}
            disabled={signupLoading || !signupForm.email}
          >
            {signupLoading ? (
              <>
                <Loader2 className="h-4 w-4 animate-spin mr-2" />
                Processing...
              </>
            ) : (
              "Get Access & Download Reports"
            )}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );

  // ─── Main Render ────────────────────────────────────────────────────────

  return (
    <div className="min-h-screen flex flex-col">
      <AnimatePresence mode="wait">
        {view === "landing" && (
          <motion.div key="landing" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} transition={{ duration: 0.2 }}>
            {renderHero()}
          </motion.div>
        )}
        {view === "browse" && (
          <motion.div key="browse" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} transition={{ duration: 0.2 }} className="flex-1">
            {renderBrowse()}
            {renderFooter()}
          </motion.div>
        )}
        {view === "detail" && (
          <motion.div key="detail" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} transition={{ duration: 0.2 }} className="flex-1">
            {renderDetail()}
            {renderFooter()}
          </motion.div>
        )}
      </AnimatePresence>

      {renderSignupModal()}
    </div>
  );
}